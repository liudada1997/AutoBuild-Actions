#!/bin/sh

log() {
	logger -t "sdcard" "$@"
}

exit 0

